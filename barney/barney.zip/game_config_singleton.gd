extends Node

var config: Resource

func _ready():
	config = load("res://barney/game_config.tres")
